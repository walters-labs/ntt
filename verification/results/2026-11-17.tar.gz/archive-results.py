"""Freeze the completed 2048-point proof evidence, sources, and toolchain."""
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

root = Path('/Users/jackson/GitHub/ntt')
sys.path.insert(0, str(root / 'verification'))
from math_proof import validate_graph as validate_math
from model_proof import validate_graph as validate_models

pair_paths = [Path(arg) for arg in sys.argv[1:]]
if len(pair_paths) != 2:
    raise SystemExit('Supply the two successful paired proof reports')
cases = {'2048-12289', '2048-151019521'}
pairs = [json.loads((root / p).read_text()) for p in pair_paths]
if {p['case'] for p in pairs} != cases or any(p['status'] != 'passed' for p in pairs):
    raise SystemExit('Both 2048-point gates must pass before archiving')
for case in cases:
    validate_math(root / f'target/verification-math/{case}/math-result.json', case)
    validate_models(root / f'target/verification-models/{case}/model-result.json', case)

files = {}
def add(path, name=None):
    path = Path(path)
    if path.is_file() and '__pycache__' not in path.parts:
        files[name or str(path.relative_to(root))] = path

for directory in ['target/verification-isolated', 'target/verification-math', 'target/verification-models']:
    for path in (root / directory).rglob('*'):
        add(path)
build = root / 'target/verification-2048'
for pattern in ['build-report.json', 'artifacts.jsonl', '*.py', '*.tar.gz', 'artifacts/*.json']:
    for path in build.glob(pattern):
        add(path)
add(root / 'verification/results/2026-11-16.tar.gz')
for directory in ['verification', 'src', 'tests', 'benches', '.github']:
    for path in (root / directory).rglob('*'):
        if path.suffix in {'.saw', '.cry', '.py', '.sh', '.rs', '.md', '.yml', '.yaml'}:
            add(path, 'source/2026-11-17/' + str(path.relative_to(root)))
for name in ['Cargo.toml', 'Cargo.lock', 'README.md', 'LICENSE', '.gitignore']:
    add(root / name, 'source/2026-11-17/' + name)
add(Path(__file__), 'archive-results.py')
manifest = {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in sorted(files.items())}
output = root / 'verification/results/2026-11-17.tar.gz'
temporary = output.with_suffix('.tmp')
with tarfile.open(temporary, 'w:gz', compresslevel=9) as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
    data = (json.dumps(manifest, indent=2) + '\n').encode()
    info = tarfile.TarInfo('manifest.json'); info.size = len(data)
    archive.addfile(info, io.BytesIO(data))
with tarfile.open(temporary, 'r:gz') as archive:
    for name, expected in manifest.items():
        if hashlib.sha256(archive.extractfile(name).read()).hexdigest() != expected:
            raise RuntimeError('Archive verification failed: ' + name)
temporary.replace(output)
print(f'Archived and checked {len(manifest)} files: {output} ({output.stat().st_size:,} bytes)')
