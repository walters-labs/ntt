#!/usr/bin/env python3
"""Check the provenance and shared boundary of two successful SAW runs.

This records their logical connection; it does not import logs as SAW theorems
or replace either proof. Both runs must have proved unconditional statements.
"""

import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parent.parent
CASES = {
    "8-17": (8, 17, "Ntt8.cry", "convolution-8-17.saw"),
    "1024-12289": (1024, 12289, "Ntt1024.cry", "convolution-1024.saw"),
}


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def check_run(path, entry, cryptol, marker, rust=False):
    report = json.loads(path.read_text())
    if report["status"] != "passed" or report["exit_code"] != 0:
        raise ValueError(f"Not a successful proof run: {path}")
    script = ROOT / "verification" / entry
    if str(script) not in report["command"] or digest(script) != report["entry_script_sha256"]:
        raise ValueError(f"Entry script differs from the proved script: {entry}")
    log_path = (ROOT / report["log"]).resolve()
    if not log_path.is_relative_to(ROOT):
        raise ValueError("Proof log must be inside this repository")
    log = log_path.read_text()
    if marker not in log:
        raise ValueError(f"Missing completion marker in {log_path}")
    # SAW prints the files actually loaded. Ignore unrelated proof scripts in
    # the runner's broader source inventory; editing them need not force reruns.
    loaded = set()
    for name in re.findall(r'^Loading file "([^"]+)"', log, re.MULTILINE):
        source = (ROOT / name).resolve()
        loaded.add(str(source.relative_to(ROOT)))
    required = {f"verification/{entry}", "verification/multiplication-spec.saw"}
    if not required.issubset(loaded):
        raise ValueError("The shared multiplication specification was not loaded")
    loaded.update([f"verification/{cryptol}", "verification/NttSpec.cry"])
    if rust:
        if "--detect-vacuity" not in report["command"]:
            raise ValueError("Rust verification must enable vacuity checking")
        loaded.update(str(p.relative_to(ROOT)) for p in (ROOT / "src").rglob("*.rs"))
        loaded.update(["verification/harness.rs", "Cargo.toml", "Cargo.lock"])
        if digest(Path(report["mir_path"])) != report["mir_sha256"]:
            raise ValueError("The verified MIR artifact has changed")
    hashes = {}
    for name in sorted(loaded):
        expected = report["source_sha256"].get(name)
        if expected is None or digest(ROOT / name) != expected:
            raise ValueError(f"Proof dependency changed: {name}")
        hashes[name] = expected
    return report, hashes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case", choices=CASES)
    parser.add_argument("math_report", type=Path)
    parser.add_argument("rust_report", type=Path)
    parser.add_argument("--build-report", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    n, q, cryptol, math_entry = CASES[args.case]
    try:
        math, math_hashes = check_run(args.math_report, math_entry, cryptol,
            f"Verified complete {n}-point convolution theorem and multiplication specification bridge")
        rust, rust_hashes = check_run(args.rust_report, f"spectral-{args.case}.saw", cryptol,
            f"Verified Rust multiplication against shared spectral product for all i64 inputs: {n}_{q}", rust=True)
        build = json.loads(args.build_report.read_text())
        if build["status"] != "passed" or build["mir_sha256"] != rust["mir_sha256"]:
            raise ValueError("Build provenance does not match the verified MIR")
        for name, sha in build["source_sha256"].items():
            if rust_hashes.get(name) != sha:
                raise ValueError(f"Verified Rust source differs from the build input: {name}")
        for name in math_hashes.keys() & rust_hashes.keys():
            if math_hashes[name] != rust_hashes[name]:
                raise ValueError(f"The two runs used different versions of {name}")
    except (ValueError, KeyError, OSError) as error:
        parser.error(str(error))
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    output = args.output or ROOT / "target/verification-isolated" / f"paired-{args.case}-{stamp}.json"
    result = {
        "status": "passed", "case": args.case,
        "method": "Two unconditional SAW proofs connected by the same spectral-product definition",
        "math_report": str(args.math_report.resolve()), "math_report_sha256": digest(args.math_report),
        "rust_report": str(args.rust_report.resolve()), "rust_report_sha256": digest(args.rust_report),
        "build_report": str(args.build_report.resolve()), "build_report_sha256": digest(args.build_report),
        "checker_sha256": digest(Path(__file__).resolve()),
        "shared_spec_sha256": math_hashes["verification/multiplication-spec.saw"],
        "source_sha256": math_hashes | rust_hashes, "mir_sha256": rust["mir_sha256"],
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(f"Validated split proof for {args.case}: {output}")


if __name__ == "__main__":
    main()
