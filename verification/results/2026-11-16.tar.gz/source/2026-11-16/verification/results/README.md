# Verification checkpoints

## November 16: split-proof workflow and sleep diagnosis

**The complete 1024-point forward, inverse, and cyclic-multiplication proofs passed.**
The mathematical run used a 10 GiB heap, a 1,800-second external deadline, and
temporary idle-sleep prevention. Wall time was 1,473.838 seconds, monotonic elapsed
time was 1,473.860 seconds, child CPU time was 1,458.831 seconds, and maximum child
RSS was 6.53 GiB (7,008,534,528 bytes). All recursive dependencies were proved in
that process.

The Rust run passed all 31 MIR contracts with vacuity checking: four arithmetic,
two butterfly, twenty stage, two kernel, and three public-operation contracts.
The direct-DFT model proofs also passed. It used a 10 GiB heap and a 3,600-second
external deadline, with temporary idle-sleep prevention. Wall time was
2,095.494 seconds, monotonic elapsed time was 2,095.469 seconds, child CPU time
was 2,067.397 seconds, and maximum child RSS was 5.99 GiB (6,433,193,984 bytes).
The two successful runs were sequential, totaling about 59.5 minutes; their
memory peaks are separate. These RSS figures do not measure aggregate memory
across all processes or equal the historical physical-footprint measurement.

The final provenance check passed and recorded the connection in
`paired-1024-12289-20261116T235742904639Z.json`. The corresponding run stems are
`convolution-1024-20261116T224934434035Z` and
`spectral-1024-12289-20261116T232238150010Z`. Their reports, transcripts, exact
MIR artifact, proof-source snapshot, and toolchain manifest are retained in
`2026-11-16.tar.gz`, with per-file SHA-256 hashes in its `manifest.json`.
Sources are under `source/2026-11-16/`; the MIR and run records retain their
repository-relative paths. The archive is an audit record, not an imported
SAW proof certificate; reruns still require the pinned verification toolchain.
Neither 2048-point case has been attempted.

The shared `multiplication-spec.saw` defines the spectral product used by both
the mathematical proof and the new Rust contract. The former proves its equality
to cyclic convolution for every pair of coefficient arrays; the latter proves
that Rust returns it for normalized arbitrary signed inputs. This separates
proof histories without assuming a missing mathematical theorem in the Rust run.
`check-split.py` checks successful reports, matching actual proof dependencies,
the shared definition, current Rust inputs, and the exact MIR build provenance.

The complete split workflow passed at `(8,17,9)`: the mathematical proof and
bridge used 12.034 seconds and 0.22 GiB maximum child RSS; the Rust run used
22.299 seconds and 1.36 GiB. Both used a 6 GiB heap. The Rust run enabled
vacuity checking. Negative provenance tests rejected a failed run, a changed
entry, a changed shared definition, and a changed MIR artifact. The build helper
retains MIR artifacts by SHA-256 so subsequent builds cannot overwrite evidence.

An earlier 10 GiB combined-math attempt timed out in the 512-point inverse
decomposition. SAW reported 161.895 CPU seconds versus 2,352.213 elapsed seconds;
the runner's monotonic clock recorded 189.787 seconds and maximum child RSS was
2.96 GiB. The macOS power log confirmed repeated sleep/dark-wake cycles during
that run. This was not a heap-limit failure. Older wall-time and garbage-collection
elapsed figures can include sleep and should not be equated with CPU effort.

The runner now optionally uses `caffeinate -i -w` on macOS, enforces its external
deadline against wall time, and records wall, monotonic, and child CPU times.
The temporary sleep assertion and its release were checked. Synthetic controls
also checked deadline enforcement, child-process cleanup, and failing exit status.

Inspection of the installed SAW 1.6 source found that its theorem database retains
theorems and their proof evidence, including intermediate sequents and rewrite
rules. This explains why independent checks do not establish the memory needed
to retain and compose them in one process. A 64-output recurrence probe already
had a final goal of only three DAG nodes; another final evaluation left it at
three, so final solver-goal simplification was not promoted. The expensive work
is in expanding and rewriting the dense specifications and retaining the evidence.
See [SAW's theorem and evidence representation](https://github.com/GaloisInc/saw-script/blob/68eed5f/saw-central/src/SAWCentral/Proof.hs#L942).

An initial Rust run with a 1,800-second overall deadline was deliberately
stopped after consulting the earlier stage/model/kernel timings: that deadline
was too short for the expected work. Its report records exit code -15. The
successful replacement above used a 3,600-second deadline; no proof obligation
was waived. The split regression and unsuccessful diagnostic runs are archived
alongside the successful pair and the historical results below. No proof process
was left running after the completed pair.

## November 16: bounded mathematical checks passed

`recurrence-1024.saw` proved the even/odd schoolbook-convolution recurrence for
two arbitrary 1024-element coefficient arrays at modulus 12289. It uses the
same algebraic tactics as the full theorem, extracted without changes into
`math-tactics.saw`, and checks all outputs in chunks of 64. No Rust MIR was loaded.

`forward-split-1024.saw` subsequently proved that the direct 1024-point DFT
equals the combination of its even/odd 512-point DFTs, for arbitrary coefficient
arrays. The roots come from the same validated parameters used by the full
convolution proof, and this check also uses 64-output chunks.

`inverse-split-1024.saw` proved the corresponding inverse decomposition,
including the inverse-length scaling and the half-sum/half-difference inputs.
It uses the same validated parameters and 64-output chunking.

`inverse-linearity-1024.saw` proved inverse additivity modulo 12289 for arbitrary
512-element arrays, using the half-size root and inverse length required by the
1024-point convolution theorem.

`inverse-shift-1024.saw` proved that multiplying an arbitrary 512-element input
by successive powers of the half-size forward root before the inverse transform
equals rotating the inverse-transform output right by one position. It uses
the same half-size parameters and 64-output chunking.

`spectral-sums-1024.saw` proved the sum decomposition of the pointwise product
of two combined spectra, for four arbitrary 512-element coefficient arrays.
Taking the modular half-sums cancels the cross terms and leaves the first
pair's pointwise product plus the second pair's product multiplied by successive
powers of the half-size root. It uses the same parameters and 64-output chunking.

`spectral-diffs-1024.saw` proved the corresponding difference decomposition
for four arbitrary 512-element coefficient arrays. Subtracting the two product
halves, dividing by two modulo 12289, and removing the forward-root powers
leaves the sum of the cross products. It uses the same parameters and
64-output chunking.

| Isolated lemma | Result | Elapsed time | Maximum child RSS |
| --- | --- | --- | --- |
| Schoolbook recurrence | Passed, exit 0 | 238.789 seconds | 4.28 GiB |
| Forward DFT decomposition | Passed, exit 0 | 248.036 seconds | 2.28 GiB |
| Inverse DFT decomposition | Passed, exit 0 | 246.318 seconds | 3.68 GiB |
| Inverse linearity (512-point subtransforms) | Passed, exit 0 | 100.791 seconds | 2.45 GiB |
| Inverse shift (512-point subtransforms) | Passed, exit 0 | 64.971 seconds | 1.63 GiB |
| Spectral product sums (512 outputs) | Passed, exit 0 | 9.629 seconds | 0.33 GiB |
| Spectral product differences (512 outputs) | Passed, exit 0 | 10.489 seconds | 0.34 GiB |

- All seven runs used a **6 GiB SAW heap** and a **600-second external wall deadline**.
- The small complete 16-point mathematical theorem and bridge passed after the
  shared-tactic extraction, in 14.499 seconds with 0.22 GiB maximum child RSS.
- The external timeout was checked with a synthetic parent/solver-child pair;
  both were stopped at the deadline. Termination cleanup is also checked.

The logs and source-hash reports are retained in `2026-11-16.tar.gz`. These
memory measurements are resident-memory statistics, not the physical-footprint
measurement used for the previous 29 GiB session. The heap limit also does not
bound aggregate memory of all solver processes.

This earlier checkpoint established all seven top-level component identities
independently within the stated budget. Those checks alone did **not** establish
the full 1024-point convolution theorem or public multiplication API; the later
successful pair is recorded above. Separate logs cannot be imported as proved
SAW theorems.

### Combined convolution attempt: heap limit reached

`convolution-1024.saw` runs the recursive theorem and specification bridge in one
fresh process, proving every smaller-length dependency before reuse. The first
attempt used a 6 GiB SAW heap and a 1,800-second external deadline. It failed
with exit code 2 and `heap overflow` during the 1024-point schoolbook recurrence.
Maximum child RSS was 6.12 GiB. The runner recorded 1,582.493 seconds of monotonic
elapsed time; SAW's runtime report recorded 1,797.386 elapsed seconds. These
measurements differ and are retained as reported, without equating them.

The complete convolution theorem passed through length 512. At length 1024,
forward decomposition, inverse decomposition, inverse linearity, and inverse
shift passed before the heap failure. The final 1024-point composition and
specification bridge were not reached. This is a resource failure, not a
counterexample, and it does not establish the full multiplication claim.

SAW reported 972.949 elapsed seconds in garbage collection, over half its
reported elapsed run time. The 64-output recurrence that passed independently
did not fit the same heap cap after the other proofs in the combined session.
The failed log and source-hash report are retained in `2026-11-16.tar.gz`.

An isolated recurrence experiment with 32-output chunks passed in 238.592 seconds
with 4.34 GiB maximum child RSS. The original 64-output check used 238.789 seconds
and 4.28 GiB. Halving the chunks did not improve peak memory, so the 64-output
entry was restored. The experimental entry, log, and hash report are archived.

A second isolated experiment wrapped each recursive vector half in `subproof`,
retaining the original 64-output chunks. It passed in 242.608 seconds with
4.55 GiB maximum child RSS, also offering no memory improvement. The variant
and its entry, log, and hash report are archived; `vector-proofs.saw` is unchanged.
Neither experiment justifies another full run with the same heap budget.
At that checkpoint, the next diagnostic was to examine retained proof data
between lemmas before changing the composition strategy. No proof process was
left running at that checkpoint.

## November 15: cleanup and checkpoint

Work was paused at this checkpoint; no proof process was left running overnight.

### Established results

- Forward, inverse, and cyclic multiplication at `(8,17,9)`, `(16,17,3)`,
  `(8,289,110)`, and `(256,12289,8340)`: 48 required MIR contracts in total.
- Arithmetic, butterfly, parameter, and ML-KEM power foundations: 139 contracts.
- At `(1024,12289,10302)`: arithmetic, butterflies, all 20 stages, direct-DFT
  models, both kernels, and public forward/inverse operations passed.
  Public cyclic multiplication is **not proved**. The interactive transcript
  includes retries and failures; its raw success count includes a repeated
  forward-kernel proof and is not a count of distinct completed contracts.
- The 1024-point schoolbook recurrence passed alone with 64-output chunks in
  about 344 seconds. Completing the entire convolution theorem in the large
  session timed out, with a peak process footprint of about 29 GiB.
- The 6 GiB heap setting passed the small mathematical regression and all seven
  contracts of the 8-point Rust/MIR case. No complete 1024-point run has passed
  under this limit. Neither 2048-point case has been attempted.

### Resume instructions at that checkpoint

The target remains the three fixed tuples in [the roadmap](../roadmap.md), with
arbitrary signed coefficients. Consumer adapters and arbitrary generic API
parameters are separate work.

Start with a **math-only, isolated recurrence check** in a fresh SAW process,
with a short explicit timeout and `+RTS -M6G -RTS`. Establish its memory use
before attempting another full run. Do not restart the full 1024-point script
as the first experiment.

Keep expensive lemmas in separate top-level proof commands. A failed SAW
`include` rolls back that include's bindings, even when earlier statements
succeeded; retrying the whole include repeats that work. Native `define` aliases
can survive such a failure and collide on redefinition.

An experimental `subproof` wrapper around each half of the vector-splitting
tactic passed the 16-point mathematical check. Its 1024-point retry was stopped
while closing the session; treat it as inconclusive. It has not been promoted
into the maintained scripts. The archive retains this small experiment for
reference, along with the isolated recurrence that definitely passed.

### Retained evidence

`2026-11-15.tar.gz` contains selected original transcripts, the relevant small
experiment scripts, the dependency lockfile, and hashes of the source used for
the 1024-point MIR build. `manifest.json` inside the archive lists file hashes.
The archived paths are relative to the repository root. Historical scripts may
refer to deleted build directories; this archive is an audit record, not a
standalone runner or reusable proof certificate.

The original MIR loaded by the interactive session had SHA-256
`8e474cb30f6d81aae08060c93204d2a1e8c29d2929db4fd7fe875c41e057429c`.
It was later overwritten by a rebuild with different allocation identifiers;
the production Rust, harness, and mathematical specification were unchanged.
The archive does not contain that original MIR artifact.

Disposable build directories, abandoned Verus tooling, and duplicate diagnostic
experiments have been removed. The pinned Cryptol, SAW, mir-json installation,
translated standard libraries, and required Rust nightly are retained. The
normal runners rebuild the project's MIR and logs when needed.

Before this checkpoint, formatting, Clippy with warnings denied, and all 21
Rust tests (including doctests) passed in debug and release modes. A fresh MIR
build also passed after deleting mir-json's installation build cache. No large
formal proof was rerun during cleanup.
